<?php
$conn = mysqli_connect("localhost", "root", "", "db-andri");

if (!$conn) {
    die("connection failed :" . mysqli_connect_error());
    exit();
}
