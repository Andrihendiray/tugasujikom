<?php
require 'function/db-andri.php';

// if (isset($_POST['tipe_kamar'])) {
//     $tipe_kamar = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['tipe_kamar']));
//     $get        = mysqli_query($conn, "SELECT * FROM kamar WHERE tipe_kamar = '$tipe_kamar'");
//     $result     = mysqli_fetch_assoc($get);

//     echo $result['harga'] . "/" . $result['tipe_kamar'] . "/" . $result['images'];

